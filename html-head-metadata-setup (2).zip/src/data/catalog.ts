export type CourseType = "Full" | "Mini" | "PYQ" | "Free";
export type CoverVariant =
  | "contour"
  | "monsoon"
  | "climate"
  | "river"
  | "city"
  | "glacier"
  | "gis"
  | "population"
  | "ocean"
  | "isotherm"
  | "comprehension";

export type Course = {
  id: string;
  title: string;
  type: CourseType;
  exam: string;
  subject: string;
  cover: CoverVariant;
  blurb: string;
  lessons: string;
  validity: string;
  demo: boolean;
  updated: boolean;
  notes: boolean;
  doubt: boolean;
  notice?: string;
  highlights: string[];
  syllabus: string[];
};

export type Promo = {
  code: string;
  title: string;
  subtitle: string;
  percent: number;
  bonus: string;
  applies: string;
  detail: string;
  points: string[];
};

export type Educator = {
  name: string;
  role: string;
  initials: string;
  bio: string;
  credentials: string[];
  socials: { label: string; handle: string; href: string; kind: "youtube" | "telegram" | "whatsapp" }[];
};

export type Testimonial = {
  name: string;
  initials: string;
  place: string;
  rating: number;
  quote: string;
  educator: string;
};

export const examTracks = ["All Exams", "UGC-NET-Geography", "UPSC-Geography", "Class-11-12", "CTET-EVS"] as const;

export const courses: Course[] = [
  {
    id: "geo-full-net",
    title: "UGC-NET Geography Full Course",
    type: "Full",
    exam: "UGC-NET-Geography",
    subject: "Physical, Human, Indian & Regional Geography",
    cover: "contour",
    blurb:
      "The complete Paper-II route: every unit of the UGC-NET Geography syllabus, taught section by section with map work and previous-question practice built in.",
    lessons: "128 lectures · 9 sections",
    validity: "Unlimited validity",
    demo: true,
    updated: true,
    notes: true,
    doubt: true,
    notice:
      "Includes a section-wise PYQ bank with every lecture. It does NOT include a separate paid test series — nothing here has a fee.",
    highlights: [
      "All 9 syllabus units, in exam order",
      "One-page revision notes for every lecture",
      "Section-wise PYQs with explanation, not just answers",
      "Weekly doubt sessions on the FREE channel",
    ],
    syllabus: [
      "Geomorphology & Landforms",
      "Climatology & Atmospheric Circulation",
      "Oceanography",
      "Biogeography & Environmental Geography",
      "Population, Settlement & Migration",
      "Economic Geography & Resources",
      "Indian Geography: Physical",
      "Indian Geography: Human & Economic",
      "Geographical Thought, Models & Quantitative Techniques",
    ],
  },
  {
    id: "geo-full-upsc",
    title: "UPSC Geography Optional — Full Course",
    type: "Full",
    exam: "UPSC-Geography",
    subject: "Paper I + Paper II (Mains)",
    cover: "gis",
    blurb:
      "Both optional papers, sequenced for Mains answer writing: concepts first, then diagrams, map marking and previous-year question decoding.",
    lessons: "96 lectures · 2 papers",
    validity: "Unlimited validity",
    demo: true,
    updated: true,
    notes: true,
    doubt: true,
    notice:
      "This is an optional-subject course. It does not cover GS Paper I geography questions separately, but the same notes serve them well.",
    highlights: [
      "Physical geography fundamentals with diagrams",
      "Human & economic geography with Indian examples",
      "Answer-writing clinic with structure templates",
      "Map-marking practice sets for every unit",
    ],
    syllabus: [
      "Tectonics, Landforms & Geomorphology",
      "Climatology, Oceanography & Biogeography",
      "Models in Human Geography",
      "Planning, Migration & Urban Systems",
      "Resources, Agriculture & Industry of India",
      "Transport, Trade & Spatial Inequality",
      "Disaster Management & Vulnerability",
      "Map Work, Diagrams & Answer Presentation",
    ],
  },
  {
    id: "geo-full-school",
    title: "Class 11–12 Geography Foundation",
    type: "Full",
    exam: "Class-11-12",
    subject: "Fundamentals of Physical Geography + India: People & Economy",
    cover: "monsoon",
    blurb:
      "A board-friendly build-up of physical and human geography that quietly prepares you for competitive exams two years later.",
    lessons: "54 lectures · NCERT-aligned",
    validity: "Unlimited validity",
    demo: true,
    updated: false,
    notes: true,
    doubt: false,
    highlights: [
      "Chapter-by-chapter, in NCERT order",
      "Diagrams you can copy in the exam",
      "Board-style answer frameworks",
      "Bridge notes toward NET & UPSC depth",
    ],
    syllabus: [
      "Geography as a Science, Space of the Earth",
      "Interior of the Earth & Plate Tectonics",
      "Weathering, Mass Wasting & Landforms",
      "Atmosphere, Temperature & Pressure Systems",
      "Hydrosphere, Water Cycles & Ocean Relief",
      "Soil, Natural Vegetation & Wildlife",
      "Indigenous Communities in India",
      "Population, Settlements, Transport & Trade",
    ],
  },
  {
    id: "geo-climate",
    title: "Climatology Course",
    type: "Mini",
    exam: "UGC-NET-Geography",
    subject: "Climate · Circulation · Change",
    cover: "climate",
    blurb:
      "Pressure belts, monsoon mechanics, climate classifications and change — a single section, covered completely.",
    lessons: "18 lectures",
    validity: "Free forever",
    demo: true,
    updated: true,
    notes: true,
    doubt: false,
    notice: "READ CAREFULLY — this course covers the CLIMATOLOGY section only, not the entire syllabus.",
    highlights: ["Aeolotropic and heat budget basics", "Monsoon: onset, burst, break", "Köppen to Trewartha, decoded", "Current climate-change evidence"],
    syllabus: ["Solar Radiation & Heat Budget", "Pressure & Wind Systems", "Monsoon Dynamics", "Climate Classification", "Aridity & Drought", "Climate Change & IPCC"],
  },
  {
    id: "geo-geomorph",
    title: "Geomorphology Course",
    type: "Mini",
    exam: "UGC-NET-Geography",
    subject: "Landforms · Cycles · Structures",
    cover: "contour",
    blurb: "From the theory of continental drift to fluvial, aeolian and karst cycles — with the landform diagrams that fetch marks.",
    lessons: "16 lectures",
    validity: "Free forever",
    demo: true,
    updated: true,
    notes: true,
    doubt: false,
    notice: "READ CAREFULLY — this course covers the GEOMORPHOLOGY section only.",
    highlights: ["Structure, process & stage in one frame", "Fluvial, aeolian, glacial, karst cycles", "Weathering & mass wasting", "Map and section diagram practice"],
    syllabus: ["Earth's Interior & Plate Tectonics", "Rock Cycle & Structures", "Weathering & Mass Wasting", "Fluvial Landforms", "Aeolian & Coastal Landforms", "Glacial & Karst Landforms"],
  },
  {
    id: "geo-ocean",
    title: "Oceanography Course",
    type: "Mini",
    exam: "UPSC-Geography",
    subject: "Relief · Currents · Salinity",
    cover: "ocean",
    blurb: "Ocean relief, temperature and salinity profiles, currents, coral reefs and the Indian Ocean — packaged for both optional papers.",
    lessons: "12 lectures",
    validity: "Free forever",
    demo: true,
    updated: false,
    notes: true,
    doubt: false,
    notice: "This course covers the OCEANOGRAPHY section only, not the entire syllabus.",
    highlights: ["Relief of the ocean floor", "Temperature & salinity controls", "Currents, upwelling and fisheries", "Coral reefs and their decline"],
    syllabus: ["Ocean Relief", "Temperature Profile", "Salinity Profile", "Waves & Tides", "Currents & Upwelling", "Coral Reefs & Indian Ocean"],
  },
  {
    id: "geo-india",
    title: "Indian Geography: Resources & People",
    type: "Mini",
    exam: "UGC-NET-Geography",
    subject: "India · Physical to Human",
    cover: "river",
    blurb: "River basins, soils, agriculture, minerals, industry and population — the Indian section, mapped region by region.",
    lessons: "21 lectures",
    validity: "Free forever",
    demo: true,
    updated: true,
    notes: true,
    doubt: false,
    notice: "READ CAREFULLY — this covers the INDIAN GEOGRAPHY section only.",
    highlights: ["Physiographic divisions of India", "River basins & water disputes", "Soil types and land use", "Population, languages & religion"],
    syllabus: ["Physiographic Divisions", "Drainage & River Basins", "Climate & Monsoon", "Soils & Vegetation", "Agriculture & Irrigation", "Minerals, Energy & Industry", "Population & Settlement"],
  },
  {
    id: "geo-gis",
    title: "GIS, Remote Sensing & Quantitative Techniques",
    type: "Mini",
    exam: "UGC-NET-Geography",
    subject: "Tools · Data · Maps",
    cover: "gis",
    blurb: "The most-scoring technical unit: sensors, resolutions, projections, spatial analysis and the statistics the NET keeps asking.",
    lessons: "15 lectures",
    validity: "Free forever",
    demo: true,
    updated: true,
    notes: true,
    doubt: false,
    notice: "Lecture 11 onward includes software demos; no installation is required to follow the theory.",
    highlights: ["Electromagnetic spectrum to image interpretation", "Projections & coordinate systems", "Vector vs raster, overlays, buffering", "Mean, median, SD, correlation, regression"],
    syllabus: ["Remote Sensing Basics", "Sensors & Resolution", "Image Interpretation", "Map Projections", "GIS Data Models", "Spatial Analysis", "Statistics for Geographers"],
  },
  {
    id: "geo-pop",
    title: "Population & Settlement Geography",
    type: "Mini",
    exam: "Class-11-12",
    subject: "Demography · Urban Systems",
    cover: "population",
    blurb: "Transition theory, density patterns, migration models, urban hierarchies and settlement morphology in plain language.",
    lessons: "11 lectures",
    validity: "Free forever",
    demo: true,
    updated: false,
    notes: true,
    doubt: false,
    notice: "This course covers POPULATION & SETTLEMENT themes only.",
    highlights: ["Pyramids and transition stages", "Density, sex ratio, dependency", "Ravenstein to Lee, migration models", "Urban hierarchy & land-use models"],
    syllabus: ["Distribution & Density", "Growth & Transition", "Migration Theories", "Urban Definitions & Systems", "Settlement Patterns", "Smart Cities & Planning"],
  },
  {
    id: "geo-bio",
    title: "Biogeography & Environmental Geography",
    type: "Mini",
    exam: "UPSC-Geography",
    subject: "Biomes · Ecosystems · Hazards",
    cover: "glacier",
    blurb: "Biomes, soils, ecosystems, biodiversity hotspots and hazard geography — the unit that links physical and human papers.",
    lessons: "10 lectures",
    validity: "Free forever",
    demo: true,
    updated: true,
    notes: true,
    doubt: false,
    notice: "This course covers BIOGEOGRAPHY & ENVIRONMENT sections only.",
    highlights: ["Biome distribution controls", "Ecosystem energy flow", "Hotspots, endemic fauna & flora", "Hazards, vulnerability, risk maps"],
    syllabus: ["Biogeographical Realms", "Biomes & Soils", "Ecosystems & Energy Flow", "Biodiversity & Conservation", "Natural Hazards", "Climate & Environmental Governance"],
  },
  {
    id: "geo-monsoon",
    title: "Monsoon & Indian Climate",
    type: "Mini",
    exam: "CTET-EVS",
    subject: "Rainfall · Seasons · El Niño",
    cover: "monsoon",
    blurb: "One compact course on the system that shapes India: mechanism, seasons, variability, floods and drought — with EVS-friendly teaching for teachers.",
    lessons: "8 lectures",
    validity: "Free forever",
    demo: true,
    updated: false,
    notes: true,
    doubt: false,
    notice: "A short course for Class 11–12, CTET EVS and general interest.",
    highlights: ["Jet streams & ITCZ", "Onset, burst, break, withdrawal", "ENSO, IOD and teleconnections", "Teaching monsoon with a map"],
    syllabus: ["Monsoon Mechanism", "Seasons of India", "Rainfall Variability", "El Niño, La Niña & IOD", "Floods & Drought", "Classroom Map Activity"],
  },
  {
    id: "geo-net-pyq",
    title: "UGC-NET Geography PYQs",
    type: "PYQ",
    exam: "UGC-NET-Geography",
    subject: "Section-wise Questions",
    cover: "isotherm",
    blurb:
      "Every previous question sorted into syllabus sections, so you revise one topic at a time instead of drowning in year-wise papers.",
    lessons: "1,180+ questions · 9 sections",
    validity: "Free forever",
    demo: true,
    updated: true,
    notes: false,
    doubt: false,
    highlights: [
      "Question bank grouped by section & topic",
      "Answer with explanation, not an answer key alone",
      "Difficulty tag so you can skip or attempt",
      "Works on phone, one question per screen",
    ],
    syllabus: ["Teaching & Research Aptitude paired sets", "Geomorphology", "Climatology", "Oceanography", "Indian Geography", "Human & Economic Geography", "Geographical Thought", "Models & Techniques", "Full-length mixed sets"],
  },
  {
    id: "geo-upsc-pyq",
    title: "UPSC Geography Optional PYQs",
    type: "PYQ",
    exam: "UPSC-Geography",
    subject: "Mains Question Bank · 2005–2025",
    cover: "comprehension",
    blurb: "Two decades of optional Mains questions, split by paper, unit and question type — with demand-of-the-question notes.",
    lessons: "640+ questions · Paper I & II",
    validity: "Free forever",
    demo: true,
    updated: true,
    notes: false,
    doubt: false,
    highlights: ["Sorted by unit and by directive word", "Model structure for long answers", "Map-marking question archive", "Repeat-theme tracker"],
    syllabus: ["Paper I — Physical Geography", "Paper I — Human Geography", "Paper II — Resources & Agriculture", "Paper II — Industry & Transport", "Paper II — Settlements & Planning", "Map-marking Sets"],
  },
  {
    id: "geo-school-pyq",
    title: "Class 11–12 Geography PYQs",
    type: "PYQ",
    exam: "Class-11-12",
    subject: "Board Question Bank",
    cover: "isotherm",
    blurb: "Board questions chapter by chapter, with marking-scheme-aware answers and the diagrams examiners expect.",
    lessons: "420+ questions · chapter-wise",
    validity: "Free forever",
    demo: true,
    updated: false,
    notes: false,
    doubt: false,
    highlights: ["Chapter-wise board archive", "Very short to long answer tagging", "Diagram checklist per chapter", "Sample answer walkthroughs"],
    syllabus: ["Fundamentals of Physical Geography", "India: Physical Environment", "Fundamentals of Human Geography", "India: People & Economy", "Practical Work & Map Skills"],
  },
  {
    id: "geo-free-syllabus",
    title: "Geography Syllabus Decoded",
    type: "Free",
    exam: "UGC-NET-Geography",
    subject: "Complete Syllabus · Orientation",
    cover: "contour",
    blurb: "Start here: what the syllabus really means, which units pay off fastest, and how to plan the first 30 days.",
    lessons: "4 lectures · free",
    validity: "No expiry",
    demo: true,
    updated: true,
    notes: true,
    doubt: false,
    highlights: ["Unit-by-unit syllabus reading", "Weightage you can actually use", "A 30-day starter plan", "What to ignore for now"],
    syllabus: ["How to Read the Syllabus", "Unit Weightage & Priority", "Notes & Revision System", "Your First 30 Days"],
  },
  {
    id: "geo-free-maps",
    title: "Map Skills in 20 Minutes",
    type: "Free",
    exam: "Class-11-12",
    subject: "Scale · Symbols · Topography",
    cover: "gis",
    blurb: "Scale, legend, contour intervals, relief shading and why a toposheet is worth more than ten paragraphs.",
    lessons: "3 lectures · free",
    validity: "No expiry",
    demo: true,
    updated: false,
    notes: true,
    doubt: false,
    highlights: ["Read scale & grid references", "Interpret contours and relief", "Toposheet legend practice", "Draw the map, remember the fact"],
    syllabus: ["Scale, Direction & Grid", "Contours & Relief", "Toposheet Reading", "Practical Map Drawing"],
  },
  {
    id: "geo-free-strategy",
    title: "Strategy Without Burnout",
    type: "Free",
    exam: "UPSC-Geography",
    subject: "Preparation Strategy",
    cover: "climate",
    blurb: "A realistic weekly timetable, a revision loop that survives busy weeks, and how to stop collecting resources.",
    lessons: "5 lectures · free",
    validity: "No expiry",
    demo: true,
    updated: true,
    notes: true,
    doubt: false,
    highlights: ["One source, three reads", "Weekly loop: learn → recall → apply", "How to build your own notes", "What to do in the last 45 days"],
    syllabus: ["Source Control", "The Revision Loop", "Note-making That Stays Useful", "Test Strategy", "Final 45 Days"],
  },
  {
    id: "geo-free-ctet",
    title: "EVS & Geography for CTET Teachers",
    type: "Free",
    exam: "CTET-EVS",
    subject: "Pedagogy · Classroom Maps",
    cover: "river",
    blurb: "How to teach geography without rote lists: local-field examples, map activities and EVS integration ideas.",
    lessons: "6 lectures · free",
    validity: "No expiry",
    demo: true,
    updated: false,
    notes: true,
    doubt: false,
    highlights: ["Neighbourhood as a geography lab", "Activity sheets you can print", "EVS-CCE assessment ideas", "Common misconceptions, fixed"],
    syllabus: ["Geography in EVS", "Local Landscape Activities", "Map Work in Class", "Assessment & CCE", "Misconceptions", "Resource List"],
  },
];

export const promos: Promo[] = [
  {
    code: "FREEALL",
    title: "Every course, ₹0",
    subtitle: "Always on",
    percent: 100,
    bonus: "No extra validity to buy",
    applies: "All Full & Mini courses",
    detail:
      "The learning itself is permanently free — lectures, notes and section-wise PYQs. This code exists so that nobody has to look for a discount.",
    points: ["No fee, ever, for courses & PYQs", "No ads inside the player", "Notes downloadable per lecture", "Valid on app and website"],
  },
  {
    code: "CERT50",
    title: "Certificate at half cost",
    subtitle: "Enrolment week",
    percent: 50,
    bonus: "+30 days print support",
    applies: "Verified course certificate",
    detail:
      "Optional, paid add-on only. Finish 80% of a course and request a verified certificate; the fee covers verification and printing, not the lectures.",
    points: ["Requires 80% course completion", "Name & email verified against enrolment", "Digital copy stays free regardless", "Ends with this enrolment week"],
  },
  {
    code: "PRINTPYQ",
    title: "Printed PYQ booklet",
    subtitle: "At cost · limited batch",
    percent: 25,
    bonus: "Free shipping in India",
    applies: "Section-wise PYQ print sets",
    detail:
      "For learners who revise on paper. The same question bank, printed and spiral-bound, at printing cost with a 25% batch discount.",
    points: ["Section-wise, with answer keys", "Spiral bound, A4, 200+ pages", "Ships in 7–10 working days", "Digital version remains free"],
  },
  {
    code: "DOUBT30",
    title: "Priority doubt support",
    subtitle: "Student support",
    percent: 30,
    bonus: "Answer within 12 hours",
    applies: "Doubt queue add-on",
    detail:
      "Free doubt sessions stay open to everyone. This add-on simply moves your question to the front of the queue with a written reply.",
    points: ["Priority over the general queue", "Written reply + short video note", "Rolling 30-day access", "Not required to complete a course"],
  },
];

export const educators: Educator[] = [
  {
    name: "Farah Naqvi",
    role: "Founder · Physical Geography & Net Paper-II",
    initials: "FN",
    bio: "Two-time UGC-NET qualified with JRF, MSc in Geography (Landform Science), eight years of classroom and online teaching. Believes a map on the page beats three paragraphs of memory.",
    credentials: ["UGC-NET JRF, Geography", "MSc Geography — Geomorphology", "Ex-lecturer, Post Graduate College", "8 years teaching online"],
    socials: [
      { label: "YouTube", handle: "@freegeography", href: "https://www.youtube.com/", kind: "youtube" },
      { label: "Telegram", handle: "t.me/freegeography", href: "https://telegram.me/", kind: "telegram" },
      { label: "WhatsApp", handle: "FREE channel", href: "https://whatsapp.com/channel/", kind: "whatsapp" },
    ],
  },
  {
    name: "Animesh Ray",
    role: "Human Geography & UPSC Optional Educator",
    initials: "AR",
    bio: "Geography optional mentor for UPSC Mains, background in urban planning and GIS. Handles the models, the statistics and the answer-writing clinics.",
    credentials: ["UGC-NET & SET, Geography", "MTech Urban Planning", "GIS trainer, certified", "Answer-writing specialist"],
    socials: [
      { label: "YouTube", handle: "@freegeography", href: "https://www.youtube.com/", kind: "youtube" },
      { label: "Telegram", handle: "t.me/freegeography", href: "https://telegram.me/", kind: "telegram" },
      { label: "WhatsApp", handle: "Teachers' group", href: "https://whatsapp.com/channel/", kind: "whatsapp" },
    ],
  },
];

export const testimonials: Testimonial[] = [
  {
    name: "Ritika Sen",
    initials: "RS",
    place: "Patna · AIR 41, NET Geography",
    educator: "Farah Naqvi",
    rating: 5,
    quote:
      "I had four different teachers' notes for the same topic and none of them settled. Farah ma'am taught geomorphology with a diagram per concept and I finally stopped re-watching lectures. The section-wise PYQ bank is what I revised in the last month.",
  },
  {
    name: "Md. Faizan",
    initials: "MF",
    place: "Ranchi · JRF, Geography",
    educator: "Farah Naqvi",
    rating: 5,
    quote:
      "Free is the part I could not believe. Everything — lectures, notes, PYQs — no paywall, no upsell in the middle of a chapter. The revision loop in the strategy course changed how I plan my week.",
  },
  {
    name: "Sneha Kulkarni",
    initials: "SK",
    place: "Nagpur · UPSC Mains attempt",
    educator: "Animesh Ray",
    rating: 5,
    quote:
      "The answer-writing clinic is the reason my optional score moved. Sir breaks the directive word first, then the structure, then the example. Human geography models finally stopped feeling like a list of names.",
  },
  {
    name: "Deepa Rathi",
    initials: "DR",
    place: "Jaipur · School teacher",
    educator: "Animesh Ray",
    rating: 4,
    quote:
      "I use the CTET EVS course with my Class 8 students. The neighbourhood map activity takes one period and they remember it all year. Thank you for keeping it free for teachers also.",
  },
  {
    name: "Karan Bisht",
    initials: "KB",
    place: "Dehradun · Class 12",
    educator: "Farah Naqvi",
    rating: 5,
    quote:
      "Board + NET basics in the same place. The toposheet lecture is worth rewatching before every map question. Maps finally make sense instead of being a guess work.",
  },
  {
    name: "Nusrat Jahan",
    initials: "NJ",
    place: "Guwahati · SET qualified",
    educator: "Animesh Ray",
    rating: 5,
    quote:
      "Quantitative techniques used to be my skip-list. Sir teaches the statistics with geography data, so the formula has a story. Two attempts, cleared in the third.",
  },
  {
    name: "Amit Dwivedi",
    initials: "AD",
    place: "Prayagraj · Repeat aspirant",
    educator: "Farah Naqvi",
    rating: 5,
    quote:
      "I used to spend more time finding resources than studying them. Everything on FREE is in one order — learn, revise, attempt. That discipline is what moved my rank.",
  },
  {
    name: "Lhakpa Sherpa",
    initials: "LS",
    place: "Gangtok · Class 12 + NET",
    educator: "Farah Naqvi",
    rating: 4,
    quote:
      "The glacier and periglacial section was the first time my local landscape appeared in a textbook explanation. Small thing, but it made the whole chapter stick.",
  },
];

export const policyPages: Record<string, { title: string; updated: string; intro: string; blocks: { heading: string; paras: string[]; list?: string[] }[] }> = {
  privacy: {
    title: "Privacy Policy",
    updated: "Last updated: June 2026",
    intro: "FREE (Geography) collects the smallest amount of information needed to give you course access and reply to you.",
    blocks: [
      {
        heading: "What we collect",
        paras: [
          "When you enrol in a free course we store your name, email address, optional WhatsApp number and the course you chose. When you send an enquiry we store your name, email, optional WhatsApp number, the topic you selected and your message.",
        ],
        list: [
          "No payment data is stored on this site; optional add-ons are handled by the payment gateway.",
          "We do not sell, rent or trade learner data to third parties.",
          "Analytics, where used, is aggregate and not tied to your name.",
        ],
      },
      {
        heading: "How your data is used",
        paras: [
          "Your email is used to deliver course access, share legitimate updates about the course you joined, and answer your questions. WhatsApp is used only for the specific help you asked for — technical issues, enrolment confirmations or class announcements you opted into.",
        ],
      },
      {
        heading: "Storage and retention",
        paras: [
          "Records are kept while your enrolment is active and for a reasonable period afterwards so that we can reissue access if you lose it. You may ask us to delete your record at any time; we will confirm within 7 working days.",
        ],
      },
      {
        heading: "Cookies and device session",
        paras: [
          "A session cookie keeps you signed in so you do not have to re-enter details on every device. You can sign out from all devices from your profile. Colour preference (light or dark mode) is stored locally on your device and never sent to us.",
        ],
      },
      {
        heading: "Contact",
        paras: ["For any privacy request, write to privacy@freegeography.in with the email address used at enrolment."],
      },
    ],
  },
  terms: {
    title: "Terms & Conditions",
    updated: "Last updated: June 2026",
    intro: "By using FREE (Geography) you agree to these terms. They are written to protect the learners and the educators.",
    blocks: [
      {
        heading: "Use of content",
        paras: [
          "All lectures, notes and question banks are provided for your personal exam preparation only. Sharing, re-uploading, reselling or mirroring the content — including inside other coaching material — is not permitted.",
        ],
        list: [
          "Content opens inside the app or website; bulk downloading is not available.",
          "You may quote short excerpts for classroom teaching with credit to FREE (Geography).",
          "Accounts may be suspended if access is shared commercially.",
        ],
      },
      {
        heading: "Your enrolment details",
        paras: [
          "Enrol with your own email address. Access is issued against that address and it cannot be transferred to another person. Please double-check the spelling before you confirm.",
        ],
      },
      {
        heading: "Accuracy of academic content",
        paras: [
          "Courses follow the latest published syllabus available to us at the time of recording. Exam bodies revise syllabi and patterns; where that happens, the affected lecture is flagged in its notice. Always cross-check the official notification before your exam.",
        ],
      },
      {
        heading: "Conduct",
        paras: ["Doubt sessions, comment threads and support chats should remain respectful. Harassment of educators or fellow learners leads to removal from the community without notice."],
      },
      {
        heading: "Changes to these terms",
        paras: ["We may update these terms as the platform changes. Material changes are announced on the Telegram and WhatsApp channels."],
      },
    ],
  },
  refund: {
    title: "Refund Policy",
    updated: "Last updated: June 2026",
    intro: "Courses and PYQ banks on FREE (Geography) are free, so there is nothing to refund for them. This policy covers optional paid add-ons.",
    blocks: [
      {
        heading: "What is eligible",
        paras: [
          "Only the optional paid add-ons are covered by this policy: the verified certificate, printed PYQ booklets and priority doubt support.",
        ],
        list: [
          "Printed booklet: refundable before it is dispatched, or on arrival in damaged condition.",
          "Certificate fee: refundable only if verification fails from our side.",
          "Priority doubt support: refundable within 48 hours if no reply has been issued.",
        ],
      },
      {
        heading: "What is not eligible",
        paras: ["Any fee for free learning is never charged, so no charge exists to reverse. Gateway and shipping charges are refunded at actuals where the return is our fault."],
      },
      {
        heading: "How to request",
        paras: [
          "Write to refunds@freegeography.in from your enrolment email with the order reference. Approved refunds are returned to the original payment method within 7–10 working days.",
        ],
      },
      {
        heading: "In case of a technical failure",
        paras: ["If a payment is deducted but access is not issued, the amount is refunded automatically within 24 hours once reconciled by the gateway. You may also report it on the support WhatsApp number with the transaction reference."],
      },
    ],
  },
  shipping: {
    title: "Shipping Policy",
    updated: "Last updated: June 2026",
    intro: "Digital courses need no shipping. This policy applies to printed PYQ booklets and certificates only.",
    blocks: [
      {
        heading: "Dispatch timelines",
        paras: [
          "Printed booklets are dispatched within 5–7 working days of order confirmation. Certificates are printed after verification and dispatched within 10 working days of completion being confirmed.",
        ],
      },
      {
        heading: "Coverage and charges",
        paras: ["We ship across India. Standard shipping is free during an active batch offer; express handling, where available, is charged at actuals."],
      },
      {
        heading: "Tracking",
        paras: ["A courier tracking link is sent to your enrolment email and WhatsApp number on the day of dispatch. Please keep the address provided at order time accurate — redelivery charges apply for incorrect addresses."],
      },
      {
        heading: "Damaged or missing items",
        paras: ["Report a damaged or missing parcel within 7 days of the marked delivery date with photographs. We re-dispatch after verification at no extra cost."],
      },
    ],
  },
};
