import { db } from "@/db";
import { sql } from "drizzle-orm";
import FreeGeography from "./free-experience";

export const dynamic = "force-dynamic";

async function readLearnerCount() {
  try {
    const result = await db.execute(sql`select count(*)::int as total from free_enrollments`);
    const row = Array.isArray(result) ? result[0] : undefined;
    const value = (row as { total?: number | string } | undefined)?.total;
    return typeof value === "number" ? value : Number(value ?? 0) || 0;
  } catch {
    return 0;
  }
}

export default async function HomePage() {
  const learnerCount = await readLearnerCount();
  return <FreeGeography learnerCount={learnerCount} />;
}
