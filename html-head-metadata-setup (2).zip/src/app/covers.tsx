import type { CoverVariant } from "@/data/catalog";

const palettes: Record<CoverVariant, { base: string; ink: string; glow: string }> = {
  contour: { base: "#102139", ink: "#8fb2ff", glow: "#2a4a86" },
  monsoon: { base: "#0e2338", ink: "#7fd6c8", glow: "#1d4a55" },
  climate: { base: "#1a2340", ink: "#ffcf72", glow: "#46355c" },
  river: { base: "#0c2a2b", ink: "#8de3c0", glow: "#174944" },
  city: { base: "#171d33", ink: "#a8b7ff", glow: "#33345e" },
  glacier: { base: "#10243a", ink: "#b6e6ff", glow: "#26506e" },
  gis: { base: "#13203a", ink: "#78e0ff", glow: "#26466b" },
  population: { base: "#1d1c34", ink: "#ffb9a6", glow: "#453053" },
  ocean: { base: "#0a2135", ink: "#7fc9ff", glow: "#154a6e" },
  isotherm: { base: "#1b2130", ink: "#ffd08a", glow: "#3a3a55" },
  comprehension: { base: "#14232f", ink: "#9fe0d0", glow: "#2b4b52" },
};

function art(variant: CoverVariant) {
  switch (variant) {
    case "contour":
      return (
        <g fill="none" strokeWidth="1.1">
          <path d="M-10 118c40-26 66 8 104-14s52 10 88-12 62 6 96-16" />
          <path d="M-10 100c40-26 66 8 104-14s52 10 88-12 62 6 96-16" />
          <path d="M-10 82c40-26 66 8 104-14s52 10 88-12 62 6 96-16" />
          <path d="M-10 64c40-26 66 8 104-14s52 10 88-12 62 6 96-16" />
          <ellipse cx="150" cy="44" rx="26" ry="12" />
          <ellipse cx="150" cy="44" rx="12" ry="6" />
          <circle cx="150" cy="44" r="2" fill="currentColor" stroke="none" />
        </g>
      );
    case "monsoon":
      return (
        <g fill="none" strokeWidth="1.1">
          <path d="M8 24c26 0 34 16 58 16s32-16 58-16 34 16 58 16 32-16 58-16" />
          <path d="M14 58c26 0 34 16 58 16s32-16 58-16 34 16 58 16" />
          <path d="M30 96v26M52 100v26M74 96v26M96 102v26M118 96v26M140 100v26M162 96v26M184 102v26M206 96v26M228 100v26M250 96v26" />
          <path d="M150 150c0-14 10-22 22-22s22 8 22 22" />
        </g>
      );
    case "climate":
      return (
        <g fill="none" strokeWidth="1.1">
          <path d="M18 138h228M18 34v104" />
          <path d="M18 118c22-4 30-52 52-56s30 30 52 26 30-52 52-56 30 34 52 30 24-22 40-24" />
          <path d="M28 138v-18M52 138v-30M76 138v-44M100 138v-58M124 138v-52M148 138v-38M172 138v-26M196 138v-18M220 138v-10" strokeWidth="3.4" opacity=".55" />
        </g>
      );
    case "river":
      return (
        <g fill="none" strokeWidth="1.2">
          <path d="M20 22c18 24-8 40 14 60s-6 34 16 52 4 22 8 30" />
          <path d="M34 82c22-6 34-22 60-18s30 26 54 22 28-24 52-22" />
          <path d="M108 46c-14 16 4 30-8 46s10 26 2 42" />
          <path d="M154 108c-22 6-30 22-52 20s-30-18-52-14" opacity=".6" />
          <circle cx="34" cy="82" r="3" fill="currentColor" stroke="none" />
          <circle cx="108" cy="46" r="3" fill="currentColor" stroke="none" />
          <circle cx="154" cy="108" r="3" fill="currentColor" stroke="none" />
        </g>
      );
    case "city":
      return (
        <g fill="none" strokeWidth="1">
          <path d="M12 148h240M60 20v128M132 20v128M204 20v128" opacity=".5" />
          <rect x="26" y="96" width="26" height="52" />
          <rect x="58" y="70" width="20" height="78" />
          <rect x="84" y="112" width="30" height="36" />
          <rect x="122" y="52" width="24" height="96" />
          <rect x="152" y="92" width="34" height="56" />
          <rect x="194" y="66" width="22" height="82" />
          <rect x="222" y="108" width="24" height="40" />
          <path d="M26 112h26M122 74h24M152 118h34" opacity=".7" />
        </g>
      );
    case "glacier":
      return (
        <g fill="none" strokeWidth="1.1">
          <path d="M14 138l52-72 26 34 30-52 34 44 24-24 62 70H14Z" />
          <path d="M40 116c26-8 40 10 66 2s40 12 66 4" opacity=".8" />
          <path d="M96 92l26 34M146 72l24 32" opacity=".6" />
          <path d="M14 20c30 8 44-10 74-2s44 14 74 6 44-12 70-4" opacity=".45" />
        </g>
      );
    case "gis":
      return (
        <g fill="none" strokeWidth="1">
          <rect x="30" y="24" width="180" height="52" rx="4" transform="skewX(-8)" opacity=".75" />
          <rect x="46" y="60" width="180" height="52" rx="4" transform="skewX(-8)" opacity=".9" />
          <rect x="62" y="96" width="180" height="52" rx="4" transform="skewX(-8)" />
          <path d="M40 40h60M40 52h38M56 76h86M56 88h54M72 112h92M72 124h60" opacity=".7" />
          <circle cx="206" cy="44" r="7" />
          <path d="M206 51c-6-8-10-12-10-18a10 10 0 0 1 20 0c0 6-4 10-10 18Z" opacity=".8" />
        </g>
      );
    case "population":
      return (
        <g fill="none" strokeWidth="1.1">
          <path d="M132 14V146" opacity=".6" />
          <path d="M132 22h-30v16h30zM132 22h30v16h-30zM132 42h-52v16h52zM132 42h52v16h-52zM132 62h-40v16h40zM132 62h40v16h-40zM132 82h-26v16h26zM132 82h26v16h-26zM132 102h-16v16h16zM132 102h16v16h-16zM132 122h-8v16h8zM132 122h8v16h-8z" />
          <path d="M60 146h144" opacity=".5" />
        </g>
      );
    case "ocean":
      return (
        <g fill="none" strokeWidth="1.1">
          <path d="M6 40c30 0 40 14 70 14s40-14 70-14 40 14 70 14 34-14 64-14" />
          <path d="M6 64c30 0 40 14 70 14s40-14 70-14 40 14 70 14 34-14 64-14" opacity=".8" />
          <path d="M6 88c30 0 40 14 70 14s40-14 70-14 40 14 70 14 34-14 64-14" opacity=".6" />
          <path d="M6 112c30 0 40 14 70 14s40-14 70-14 40 14 70 14 34-14 64-14" opacity=".4" />
          <path d="M96 128c14-10 26 10 40 0s24 8 40-2" strokeWidth="1.6" />
        </g>
      );
    case "isotherm":
      return (
        <g fill="none" strokeWidth="1">
          <path d="M18 30h228M18 62h228M18 94h228M18 126h228" opacity=".3" />
          <path d="M18 30h228M18 62h228M18 94h228M18 126h228" strokeDasharray="1 7" />
          <path d="M30 138c18-24 36 6 54-16s40 12 58-14 34 14 52-10 26 12 34 4" strokeWidth="1.6" />
          <path d="M30 116c18-22 36 4 54-14s40 10 58-12 34 12 52-8 26 10 34 2" opacity=".65" strokeWidth="1.4" />
          <text x="216" y="52" fontSize="15" fill="currentColor" stroke="none" opacity=".8">20°</text>
          <text x="216" y="84" fontSize="15" fill="currentColor" stroke="none" opacity=".6">15°</text>
        </g>
      );
    case "comprehension":
    default:
      return (
        <g fill="none" strokeWidth="1.1">
          <rect x="26" y="22" width="118" height="112" rx="5" />
          <path d="M44 48h82M44 66h82M44 84h60M44 102h74M44 120h44" opacity=".7" />
          <rect x="162" y="34" width="76" height="52" rx="5" />
          <path d="M176 54h48M176 68h34" opacity=".7" />
          <path d="M170 104h68M170 118h50M170 132h60" opacity=".5" />
          <circle cx="192" cy="122" r="0" />
        </g>
      );
  }
}

export function Cover({ variant, label, className = "" }: { variant: CoverVariant; label?: string; className?: string }) {
  const palette = palettes[variant] ?? palettes.contour;
  return (
    <div className={`cover-art${className ? ` ${className}` : ""}`} style={{ backgroundColor: palette.base }}>
      <svg viewBox="0 0 264 158" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
        <defs>
          <radialGradient id={`glow-${variant}`} cx="76%" cy="18%" r="82%">
            <stop offset="0%" stopColor={palette.glow} stopOpacity=".95" />
            <stop offset="100%" stopColor={palette.base} stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width="264" height="158" fill={`url(#glow-${variant})`} />
        <g stroke={palette.ink} color={palette.ink}>
          {art(variant)}
        </g>
      </svg>
      {label && <span className="cover-art__label">{label}</span>}
    </div>
  );
}
