import { db } from "@/db";
import { freeEnrollments } from "@/db/schema";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return Response.json({ error: "Please send a valid enrolment." }, { status: 400 });
  }

  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    return Response.json({ error: "Please send a valid enrolment." }, { status: 400 });
  }

  const values = payload as Record<string, unknown>;
  const fullName = typeof values.fullName === "string" ? values.fullName.trim() : "";
  const email = typeof values.email === "string" ? values.email.trim().toLowerCase() : "";
  const whatsapp = typeof values.whatsapp === "string" ? values.whatsapp.trim() : "";
  const courseId = typeof values.courseId === "string" ? values.courseId.trim() : "";
  const courseTitle = typeof values.courseTitle === "string" ? values.courseTitle.trim() : "";
  const examTrack = typeof values.examTrack === "string" ? values.examTrack.trim() : "";
  const trap = typeof values.website === "string" ? values.website.trim() : "";

  if (trap) return Response.json({ ok: true, seat: 0, quiet: true });

  if (fullName.length < 2 || fullName.length > 120) {
    return Response.json({ error: "Please enter your full name." }, { status: 400 });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    return Response.json({ error: "Please enter a valid email — your course access is sent there." }, { status: 400 });
  }
  if (whatsapp.length > 30 || (whatsapp && whatsapp.replace(/\D/g, "").length < 7)) {
    return Response.json({ error: "Please check your WhatsApp number (optional)." }, { status: 400 });
  }
  if (!courseId || !courseTitle || courseId.length > 60) {
    return Response.json({ error: "Choose a course first, then enrol." }, { status: 400 });
  }

  try {
    const [row] = await db
      .insert(freeEnrollments)
      .values({
        fullName,
        email,
        whatsapp: whatsapp || null,
        courseId,
        courseTitle,
        examTrack: examTrack || "General Geography",
      })
      .returning({ seat: freeEnrollments.id });

    return Response.json({ ok: true, seat: row?.seat ?? 0 }, { status: 201 });
  } catch (error) {
    console.error("Unable to save enrolment", error);
    return Response.json({ error: "Could not complete enrolment. Please try again." }, { status: 500 });
  }
}
