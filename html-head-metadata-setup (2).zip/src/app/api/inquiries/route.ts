import { db } from "@/db";
import { freeInquiries } from "@/db/schema";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return Response.json({ error: "Please send a valid enquiry." }, { status: 400 });
  }

  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    return Response.json({ error: "Please send a valid enquiry." }, { status: 400 });
  }

  const values = payload as Record<string, unknown>;
  const name = typeof values.name === "string" ? values.name.trim() : "";
  const email = typeof values.email === "string" ? values.email.trim().toLowerCase() : "";
  const whatsapp = typeof values.whatsapp === "string" ? values.whatsapp.trim() : "";
  const topic = typeof values.topic === "string" ? values.topic.trim() : "";
  const message = typeof values.message === "string" ? values.message.trim() : "";
  const trap = typeof values.website === "string" ? values.website.trim() : "";

  // Honeypot: silently accept bot submissions without storing them.
  if (trap) return Response.json({ ok: true });

  if (name.length < 2 || name.length > 120) {
    return Response.json({ error: "Please enter your name (at least 2 characters)." }, { status: 400 });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    return Response.json({ error: "Please enter a valid email address." }, { status: 400 });
  }
  if (whatsapp.length > 30 || (whatsapp && whatsapp.replace(/\D/g, "").length < 7)) {
    return Response.json({ error: "Please check your WhatsApp number." }, { status: 400 });
  }
  if (!topic || topic.length > 120) {
    return Response.json({ error: "Please choose what your message is about." }, { status: 400 });
  }
  if (message.length < 10 || message.length > 2000) {
    return Response.json({ error: "Please add a short message (10–2,000 characters)." }, { status: 400 });
  }

  try {
    await db.insert(freeInquiries).values({
      name,
      email,
      whatsapp: whatsapp || null,
      topic,
      message,
    });
    return Response.json({ ok: true, message: "Message received — the FREE Geography team will reply on email." }, { status: 201 });
  } catch (error) {
    console.error("Unable to save enquiry", error);
    return Response.json({ error: "Could not save your message just now. Please try again." }, { status: 500 });
  }
}
