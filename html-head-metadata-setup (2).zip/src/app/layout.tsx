import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
const socialImage = siteUrl ? new URL("/images/amg-geography-hero.jpg", siteUrl).toString() : undefined;

export const metadata: Metadata = {
  title: "FREE (Geography) — To-the-point Courses & Section-wise PYQs",
  description:
    "Free geography courses, section-wise PYQs, notes and map skills for UGC-NET, UPSC optional, Class 11–12 and CTET. No fee, no ads, no upsell mid-lecture.",
  applicationName: "FREE (Geography)",
  icons: { icon: "/favicon.svg" },
  keywords: [
    "FREE Geography",
    "free geography courses",
    "UGC NET Geography previous year questions",
    "UPSC Geography optional free course",
    "section-wise PYQs geography",
    "climatology notes",
    "geomorphology course",
  ],
  openGraph: {
    title: "FREE (Geography) — To-the-point Courses & Section-wise PYQs",
    description: "Every geography course, note and PYQ bank — free, forever.",
    type: "website",
    siteName: "FREE (Geography)",
    ...(socialImage ? { images: [{ url: socialImage, width: 1536, height: 1024, alt: "Himalayan valley at sunrise" }] } : {}),
  },
  twitter: {
    card: "summary_large_image",
    title: "FREE (Geography)",
    description: "To-the-point courses & section-wise PYQs — without a fee.",
    ...(socialImage ? { images: [socialImage] } : {}),
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f6f8fc" },
    { media: "(prefers-color-scheme: dark)", color: "#070e1c" },
  ],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
