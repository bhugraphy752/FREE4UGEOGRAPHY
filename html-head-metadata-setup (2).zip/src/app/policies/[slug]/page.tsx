import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { policyPages } from "@/data/catalog";

export const dynamicParams = false;

export function generateStaticParams() {
  return Object.keys(policyPages).map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const page = policyPages[slug];
  if (!page) return { title: "Policy — FREE (Geography)" };
  return {
    title: `${page.title} — FREE (Geography)`,
    description: page.intro,
    robots: { index: true, follow: true },
  };
}

export default async function PolicyPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const page = policyPages[slug];
  if (!page) notFound();

  return (
    <div className="fg">
      <header className="topbar">
        <div className="wrap topbar__inner">
          <Link className="brand" href="/">
            <span className="mark" aria-hidden="true">
              <svg viewBox="0 0 44 44">
                <circle cx="22" cy="22" r="19" fill="none" stroke="currentColor" strokeWidth="1.6" />
                <circle cx="22" cy="22" r="14.5" fill="none" stroke="currentColor" strokeWidth=".8" strokeDasharray="1.6 2.6" />
                <path d="M22 6.5v31M6.5 22h31" stroke="currentColor" strokeWidth=".9" />
                <path d="m26 14-3.8 8.2L14 26l3.8-8.2L26 14Z" fill="currentColor" />
              </svg>
            </span>
            <span className="brand__text">
              <span className="brand__name">FREE<i>.</i></span>
              <span className="brand__sub">GEOGRAPHY</span>
            </span>
          </Link>
          <div className="topbar__actions">
            <Link className="enrol-btn" href="/">Back to courses</Link>
          </div>
        </div>
      </header>

      <main className="policy">
        <div className="wrap">
          <div className="policy__head">
            <Link className="policy__back" href="/">← Back to the course library</Link>
            <h1>{page.title}</h1>
            <p className="policy__updated">{page.updated}</p>
            <p className="policy__intro">{page.intro}</p>
          </div>
          <div className="policy__body">
            {page.blocks.map((block) => (
              <section key={block.heading}>
                <h2>{block.heading}</h2>
                {block.paras.map((para) => <p key={para.slice(0, 28)}>{para}</p>)}
                {block.list && (
                  <ul>
                    {block.list.map((item) => <li key={item}>{item}</li>)}
                  </ul>
                )}
              </section>
            ))}
            <section>
              <h2>Questions about this policy</h2>
              <p>Write to hello@freegeography.in from the email address used at enrolment and quote the course name. We answer policy and grievance mail within one working day.</p>
            </section>
          </div>
        </div>
      </main>

      <footer className="footer">
        <div className="wrap footer__bar" style={{ borderTop: 0 }}>
          <span>© {new Date().getFullYear()} FREE (Geography). Learning stays free.</span>
          <span>
            <Link href="/policies/privacy">Privacy</Link> · <Link href="/policies/terms">Terms</Link> · <Link href="/policies/refund">Refund</Link> · <Link href="/policies/shipping">Shipping</Link>
          </span>
        </div>
      </footer>
    </div>
  );
}
