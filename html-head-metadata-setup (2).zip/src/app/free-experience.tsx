"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { Cover } from "./covers";
import {
  courses,
  educators,
  examTracks,
  promos,
  testimonials,
  type Course,
  type Promo,
} from "@/data/catalog";

type Modal =
  | { kind: "course"; course: Course }
  | { kind: "promo"; promo: Promo }
  | { kind: "help" }
  | { kind: "enrolled"; title: string; seat: number }
  | null;

type Enrolment = { courseId: string; title: string; type: Course["type"]; at: string };

const NAV = [
  { id: "hero", label: "Home" },
  { id: "pyqs", label: "PYQs" },
  { id: "full-courses", label: "Full Course" },
  { id: "mini-courses", label: "Mini Courses" },
  { id: "free-courses", label: "Free Content" },
  { id: "about-us", label: "Educators" },
  { id: "contact", label: "Contact Us" },
];

const ROTATING = ["Updated", "To-the-point", "100% Free", "Section-wise"];

const EMPTY_ENQUIRY = { name: "", email: "", whatsapp: "", topic: "", message: "", website: "" };

export default function FreeGeography({ learnerCount }: { learnerCount: number }) {
  const [booting, setBooting] = useState(true);
  const [typed, setTyped] = useState(ROTATING[0]);
  const [deleting, setDeleting] = useState(false);
  const [wordIndex, setWordIndex] = useState(0);
  const [dark, setDark] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("hero");
  const [showTop, setShowTop] = useState(false);
  const [noticeOpen, setNoticeOpen] = useState(true);
  const [track, setTrack] = useState<(typeof examTracks)[number]>("All Exams");
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState<Modal>(null);
  const [toast, setToast] = useState("");
  const [copied, setCopied] = useState("");
  const [enrolments, setEnrolments] = useState<Enrolment[]>([]);
  const [showEnrolments, setShowEnrolments] = useState(false);
  const [enrolTarget, setEnrolTarget] = useState<Course | null>(null);
  const [enrolForm, setEnrolForm] = useState({ fullName: "", email: "", whatsapp: "", website: "" });
  const [enrolState, setEnrolState] = useState<"idle" | "sending" | "error">("idle");
  const [enrolError, setEnrolError] = useState("");
  const [contact, setContact] = useState(EMPTY_ENQUIRY);
  const [contactState, setContactState] = useState<"idle" | "sending" | "error">("idle");
  const [contactNote, setContactNote] = useState("");
  const toastTimer = useRef<number | null>(null);

  /* Boot + persisted preferences */
  useEffect(() => {
    const timer = window.setTimeout(() => setBooting(false), 520);
    try {
      const storedTheme = window.localStorage.getItem("fg-theme");
      if (storedTheme === "dark" || (!storedTheme && window.matchMedia("(prefers-color-scheme: dark)").matches)) setDark(true);
      const storedNotice = window.localStorage.getItem("fg-notice");
      if (storedNotice === "closed") setNoticeOpen(false);
      const storedEnrolments = window.localStorage.getItem("fg-enrolments");
      if (storedEnrolments) setEnrolments(JSON.parse(storedEnrolments) as Enrolment[]);
    } catch {
      /* storage may be unavailable in private mode */
    }
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem("fg-theme", dark ? "dark" : "light");
    } catch { /* ignore */ }
  }, [dark]);

  /* Typewriter */
  useEffect(() => {
    const current = ROTATING[wordIndex];
    let delay = deleting ? 55 : 92;
    if (!deleting && typed === current) delay = 1500;
    if (deleting && typed === "") delay = 220;

    const timer = window.setTimeout(() => {
      if (!deleting && typed === current) setDeleting(true);
      else if (deleting && typed === "") {
        setDeleting(false);
        setWordIndex((i) => (i + 1) % ROTATING.length);
      } else {
        setTyped(deleting ? current.slice(0, typed.length - 1) : current.slice(0, typed.length + 1));
      }
    }, delay);
    return () => window.clearTimeout(timer);
  }, [typed, deleting, wordIndex]);

  /* Scroll state + active section */
  useEffect(() => {
    const onScroll = () => {
      setShowTop(window.scrollY > 520);
      let current = "hero";
      for (const item of NAV) {
        const node = document.getElementById(item.id);
        if (node && node.getBoundingClientRect().top <= 140) current = item.id;
      }
      setActiveSection(current);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!modal) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setModal(null);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [modal]);

  const flash = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(""), 3400);
  }, []);

  const matches = useCallback(
    (course: Course) => {
      if (track !== "All Exams" && course.exam !== track) return false;
      const term = search.trim().toLowerCase();
      if (!term) return true;
      return `${course.title} ${course.subject} ${course.blurb} ${course.exam}`.toLowerCase().includes(term);
    },
    [search, track],
  );

  const visible = useMemo(() => courses.filter(matches), [matches]);
  const byType = (type: Course["type"]) => visible.filter((course) => course.type === type);

  const fullCourses = byType("Full");
  const miniCourses = byType("Mini");
  const pyqCourses = byType("PYQ");
  const freeCourses = byType("Free");
  const shownCount = visible.length;

  function goTo(id: string) {
    setNavOpen(false);
    const node = document.getElementById(id);
    if (node) node.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function persistEnrolments(next: Enrolment[]) {
    setEnrolments(next);
    try {
      window.localStorage.setItem("fg-enrolments", JSON.stringify(next));
    } catch { /* ignore */ }
  }

  async function copyCode(code: string) {
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      const field = document.createElement("textarea");
      field.value = code;
      document.body.appendChild(field);
      field.select();
      document.execCommand("copy");
      document.body.removeChild(field);
    }
    setCopied(code);
    flash(`Coupon ${code} copied to clipboard.`);
  }

  async function submitEnrolment(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (modal?.kind !== "course") return;
    setEnrolState("sending");
    setEnrolError("");

    const course = modal.course;
    try {
      const response = await fetch("/api/enrollments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...enrolForm, courseId: course.id, courseTitle: course.title, examTrack: course.exam }),
      });
      const result = (await response.json()) as { ok?: boolean; seat?: number; error?: string };
      if (!response.ok || !result.ok) throw new Error(result.error || "Enrolment failed. Please try again.");

      const seat = result.seat ?? 0;
      const next: Enrolment[] = [
        { courseId: course.id, title: course.title, type: course.type, at: new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short" }) },
        ...enrolments.filter((item) => item.courseId !== course.id),
      ];
      persistEnrolments(next);
      setEnrolForm({ fullName: "", email: "", whatsapp: "", website: "" });
      setEnrolState("idle");
      setModal({ kind: "enrolled", title: course.title, seat });
      flash("Enrolment confirmed. Check your email for access.");
    } catch (error) {
      setEnrolState("error");
      setEnrolError(error instanceof Error ? error.message : "Something went wrong.");
    }
  }

  async function submitEnquiry(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setContactState("sending");
    setContactNote("");
    try {
      const response = await fetch("/api/inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(contact),
      });
      const result = (await response.json()) as { ok?: boolean; error?: string; message?: string };
      if (!response.ok || !result.ok) throw new Error(result.error || "Could not send your message.");
      setContact(EMPTY_ENQUIRY);
      setContactState("idle");
      setContactNote(result.message || "Message received.");
      flash("Thanks — your message has reached the team.");
    } catch (error) {
      setContactState("error");
      setContactNote(error instanceof Error ? error.message : "Something went wrong.");
    }
  }

  function removeEnrolment(courseId: string) {
    persistEnrolments(enrolments.filter((item) => item.courseId !== courseId));
    flash("Removed from your enrolments on this device.");
  }

  const enrolledIds = enrolments.map((item) => item.courseId);
  const rating = 4.8;

  return (
    <div className={`fg${dark ? " fg--dark" : ""}`}>
      {booting && (
        <div className="preloader" role="status" aria-live="polite">
          <div className="preloader__mark"><CoverMark /></div>
          <div className="preloader__bar"><span /></div>
          <p>FREE <b>GEOGRAPHY</b></p>
        </div>
      )}

      {noticeOpen && (
        <div className="notice">
          <div className="wrap notice__inner">
            <p>
              <span className="notice__chip">NEW</span>
              Monsoon &amp; Indian Climate mini-course is live — free, with notes. <button type="button" onClick={() => goTo("mini-courses")}>Open it</button>
            </p>
            <button className="notice__close" type="button" aria-label="Dismiss notice" onClick={() => { setNoticeOpen(false); try { window.localStorage.setItem("fg-notice", "closed"); } catch { /* ignore */ } }}>×</button>
          </div>
        </div>
      )}

      <header className="topbar">
        <div className="wrap topbar__inner">
          <button className="brand" type="button" onClick={() => goTo("hero")} aria-label="FREE Geography — home">
            <CoverMark />
            <span className="brand__text">
              <span className="brand__name">FREE<i>.</i></span>
              <span className="brand__sub">GEOGRAPHY</span>
            </span>
          </button>

          <nav className={`nav${navOpen ? " nav--open" : ""}`} aria-label="Primary">
            {NAV.map((item) => (
              <button key={item.id} type="button" className={activeSection === item.id ? "is-active" : ""} onClick={() => goTo(item.id)}>
                {item.label}
              </button>
            ))}
          </nav>

          <div className="topbar__actions">
            <button className="icon-btn" type="button" onClick={() => setDark((v) => !v)} aria-label={dark ? "Switch to light mode" : "Switch to dark mode"} title={dark ? "Light mode" : "Dark mode"}>
              {dark ? "☀" : "☾"}
            </button>
            <button className="enrol-btn" type="button" onClick={() => setShowEnrolments((v) => !v)}>
              My courses <span>{enrolments.length}</span>
            </button>
            <button className="burger" type="button" aria-label="Toggle menu" aria-expanded={navOpen} onClick={() => setNavOpen((v) => !v)}>
              <span /><span /><span />
            </button>
          </div>
        </div>

        {showEnrolments && (
          <div className="drawer">
            <div className="wrap drawer__inner">
              <div className="drawer__head">
                <b>Your enrolments on this device</b>
                <button type="button" onClick={() => setShowEnrolments(false)}>Close</button>
              </div>
              {enrolments.length === 0 ? (
                <p className="drawer__empty">Nothing yet — open any course and tap <b>Enrol free</b>. Access details also go to your email.</p>
              ) : (
                <ul className="drawer__list">
                  {enrolments.map((item) => (
                    <li key={item.courseId}>
                      <span className="drawer__type">{item.type}</span>
                      <button type="button" className="drawer__title" onClick={() => { const course = courses.find((c) => c.id === item.courseId); if (course) { setShowEnrolments(false); setModal({ kind: "course", course }); } }}>{item.title}</button>
                      <span className="drawer__date">{item.at}</span>
                      <button type="button" className="drawer__remove" aria-label={`Remove ${item.title}`} onClick={() => removeEnrolment(item.courseId)}>×</button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        )}
      </header>

      <main>
        <section id="hero" className="hero">
          <div className="wrap hero__grid">
            <div className="hero__copy">
              <span className="tag"><span className="tag__dot" /> NO FEE ON ANY COURSE</span>
              <h1>
                The Most <span className="hero__typed">{typed}<i aria-hidden="true" /></span>
              </h1>
              <h1 className="hero__line2">Geography Courses</h1>
              <ul className="ticks">
                <li><span>✓</span> To-the-point courses, section by section</li>
                <li><span>✓</span> Section-wise PYQs with explanations</li>
                <li><span>✓</span> Notes, maps and doubt support — free</li>
              </ul>
              <div className="hero__cta">
                <button className="btn btn--primary" type="button" onClick={() => goTo("full-courses")}>Start a full course <span>→</span></button>
                <button className="btn btn--ghost" type="button" onClick={() => goTo("pyqs")}>Practise PYQs</button>
              </div>
              <dl className="stats">
                <div><dt>Courses live</dt><dd>{courses.length}</dd></div>
                <div><dt>Learners enrolled</dt><dd>{learnerCount.toLocaleString("en-IN")}</dd></div>
                <div><dt>Fee</dt><dd>₹0</dd></div>
                <div><dt>Rating</dt><dd>{rating}/5</dd></div>
              </dl>
            </div>

            <div className="hero__panel">
              <div className="hero__photo">
                <Cover variant="contour" className="hero__cover" />
                <div className="hero__photo-copy">
                  <span>PHYSICAL · HUMAN · INDIA</span>
                  <b>Read the world,<br />one section at a time.</b>
                </div>
              </div>
              <div className="hero__mini">
                <article>
                  <Cover variant="climate" />
                  <p><b>Climatology</b><span>18 lectures · free</span></p>
                  <button type="button" onClick={() => setModal({ kind: "course", course: courses.find((c) => c.id === "geo-climate")! })}>Open</button>
                </article>
                <article>
                  <Cover variant="river" />
                  <p><b>Indian Geography</b><span>21 lectures · free</span></p>
                  <button type="button" onClick={() => setModal({ kind: "course", course: courses.find((c) => c.id === "geo-india")! })}>Open</button>
                </article>
              </div>
            </div>
          </div>
        </section>

        <section className="section section--ink offers">
          <div className="wrap">
            <header className="section__head">
              <h2>Offers &amp; <span>Promos</span></h2>
              <p>Courses stay free. These codes apply only to the optional add-ons — certificates, printed booklets and priority doubt support.</p>
            </header>
            <div className="promo-grid">
              {promos.map((promo) => (
                <article className="promo-card" key={promo.code}>
                  <button type="button" className="promo-card__hit" onClick={() => setModal({ kind: "promo", promo })}>
                    <span className="promo-card__top">
                      <b>{promo.title}</b>
                      <i className="chip chip--green">{promo.code}</i>
                    </span>
                    <span className="promo-card__meta">{promo.subtitle} · {promo.percent}% off · {promo.bonus}</span>
                    <span className="promo-card__applies">{promo.applies}</span>
                    <span className="promo-card__more">View offer <i>→</i></span>
                  </button>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="filters">
          <div className="wrap filters__inner">
            <div className="filters__chips" role="group" aria-label="Filter every section by exam">
              {examTracks.map((item) => (
                <button key={item} type="button" className={track === item ? "fchip fchip--on" : "fchip"} aria-pressed={track === item} onClick={() => setTrack(item)}>
                  {item}
                </button>
              ))}
            </div>
            <label className="search">
              <span aria-hidden="true">⌕</span>
              <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search geography topics, courses, PYQs" aria-label="Search courses" />
              {search && <button type="button" aria-label="Clear search" onClick={() => setSearch("")}>×</button>}
            </label>
          </div>
          <p className="wrap filters__note">Showing {shownCount} of {courses.length} resources across every section{track !== "All Exams" ? ` · filtered to ${track}` : ""}.</p>
        </section>

        <section id="pyqs" className="section section--soft">
          <div className="wrap">
            <header className="section__head">
              <h2>Section-wise <span>PYQs</span></h2>
              <p>Previous-year questions sorted the way the syllabus is taught — topic first, year later. Free demo on every bank.</p>
            </header>
            {pyqCourses.length === 0 ? <EmptyNote onReset={() => { setTrack("All Exams"); setSearch(""); }} /> : (
              <div className="grid grid--3">
                {pyqCourses.map((course) => (
                  <article className="mini-card" key={course.id}>
                    {course.updated && <span className="glow">Updated</span>}
                    <div className="mini-card__body">
                      <div className="mini-card__text">
                        <button type="button" className="link-title" onClick={() => setModal({ kind: "course", course })}>{course.title}</button>
                        <p className="mini-card__subject">{course.subject}</p>
                        <span className="chip chip--outline">Free Demo Available</span>
                        <p className="mini-card__blurb">{course.blurb}</p>
                      </div>
                      <button type="button" className="mini-card__cover" onClick={() => setModal({ kind: "course", course })} aria-label={`Open ${course.title}`}>
                        <Cover variant={course.cover} />
                      </button>
                    </div>
                    <footer className="card-foot">
                      <span>{course.lessons}</span>
                      <button type="button" onClick={() => setModal({ kind: "course", course })}>View details →</button>
                    </footer>
                  </article>
                ))}
              </div>
            )}
          </div>
        </section>

        <section id="full-courses" className="section">
          <div className="wrap">
            <header className="section__head">
              <h2>Full <span>Courses</span></h2>
              <p>The complete exam route in one sequence: every unit, notes per lecture, PYQs attached, doubt support included.</p>
            </header>
            {fullCourses.length === 0 ? <EmptyNote onReset={() => { setTrack("All Exams"); setSearch(""); }} /> : (
              <div className="grid grid--3">
                {fullCourses.map((course) => (
                  <article className="course-card" key={course.id}>
                    <button type="button" className="course-card__cover" onClick={() => setModal({ kind: "course", course })} aria-label={`Open ${course.title}`}>
                      <Cover variant={course.cover} label={course.exam.toUpperCase()} />
                      {course.updated && <span className="glow glow--cover">Updated</span>}
                    </button>
                    <div className="course-card__body">
                      <button type="button" className="course-card__title" onClick={() => setModal({ kind: "course", course })}>
                        <b>{course.title}</b>
                      </button>
                      <p className="course-card__subject">{course.subject}</p>
                      <div className="chip-row">
                        <span className="chip chip--outline">Free Demo Available</span>
                        <span className="chip">{course.lessons.split(" · ")[0]}</span>
                      </div>
                      <p className="course-card__blurb">{course.blurb}</p>
                      {course.notice && <p className="note-line">⚠ {course.notice}</p>}
                    </div>
                    <footer className="card-foot card-foot--split">
                      <span className="price"><b>₹0</b> <s>₹2,699</s></span>
                      <span className="card-foot__btns">
                        <button type="button" className="btn btn--tiny" onClick={() => openEnrol(course)}>Enrol free</button>
                        <button type="button" className="btn btn--tiny btn--quiet" onClick={() => setModal({ kind: "course", course })}>Details</button>
                      </span>
                    </footer>
                  </article>
                ))}
              </div>
            )}
          </div>
        </section>

        <section id="mini-courses" className="section section--soft">
          <div className="wrap">
            <header className="section__head">
              <h2>Mini <span>Courses</span></h2>
              <p>One section, fully covered. Pick the unit you are weak in instead of re-watching everything.</p>
            </header>
            {miniCourses.length === 0 ? <EmptyNote onReset={() => { setTrack("All Exams"); setSearch(""); }} /> : (
              <>
                <div className="grid grid--3">
                  {miniCourses.slice(0, 3).map((course) => (
                    <article className="course-card" key={course.id}>
                      <button type="button" className="course-card__cover" onClick={() => setModal({ kind: "course", course })} aria-label={`Open ${course.title}`}>
                        <Cover variant={course.cover} label={course.subject.toUpperCase()} />
                        {course.updated && <span className="glow glow--cover">Updated</span>}
                      </button>
                      <div className="course-card__body">
                        <button type="button" className="course-card__title" onClick={() => setModal({ kind: "course", course })}><b>{course.title}</b></button>
                        <p className="course-card__subject">{course.exam} · {course.lessons}</p>
                        <div className="chip-row">
                          <span className="chip chip--outline">Free Demo Available</span>
                          {course.notes && <span className="chip">Notes</span>}
                        </div>
                        <p className="course-card__blurb">{course.blurb}</p>
                        {course.notice && <p className="note-line">⚠ {course.notice}</p>}
                      </div>
                      <footer className="card-foot card-foot--split">
                        <span className="price"><b>₹0</b> <s>₹{599 + miniCourses.indexOf(course) * 200}</s></span>
                        <span className="card-foot__btns">
                          <button type="button" className="btn btn--tiny" onClick={() => openEnrol(course)}>Enrol free</button>
                          <button type="button" className="btn btn--tiny btn--quiet" onClick={() => setModal({ kind: "course", course })}>Details</button>
                        </span>
                      </footer>
                    </article>
                  ))}
                </div>
                <div className="grid grid--rows">
                  {miniCourses.slice(3).map((course) => (
                    <article className="row-card" key={course.id}>
                      <button type="button" className="row-card__cover" onClick={() => setModal({ kind: "course", course })} aria-label={`Open ${course.title}`}>
                        <Cover variant={course.cover} />
                      </button>
                      <div className="row-card__text">
                        <button type="button" className="link-title" onClick={() => setModal({ kind: "course", course })}>{course.title}</button>
                        <p>{course.subject} · {course.lessons} · {course.validity}</p>
                      </div>
                      <div className="row-card__side">
                        {course.updated ? <span className="glow">Updated</span> : <span className="chip chip--outline">Demo free</span>}
                        <button type="button" className="btn btn--tiny" onClick={() => openEnrol(course)}>Enrol free</button>
                      </div>
                    </article>
                  ))}
                </div>
              </>
            )}
          </div>
        </section>

        <section id="free-courses" className="section">
          <div className="wrap">
            <header className="section__head">
              <h2>Free <span>Content</span></h2>
              <p>Orientation, strategy and map skills. No enrolment wall — open it and read.</p>
            </header>
            {freeCourses.length === 0 ? <EmptyNote onReset={() => { setTrack("All Exams"); setSearch(""); }} /> : (
              <div className="grid grid--3">
                {freeCourses.map((course) => (
                  <article className="mini-card mini-card--free" key={course.id}>
                    {course.updated && <span className="glow">Updated</span>}
                    <div className="mini-card__body">
                      <div className="mini-card__text">
                        <button type="button" className="link-title" onClick={() => setModal({ kind: "course", course })}>{course.title}</button>
                        <p className="mini-card__subject">{course.subject}</p>
                        <span className="chip chip--green">No login needed</span>
                        <p className="mini-card__blurb">{course.blurb}</p>
                        <ul className="dot-list">
                          {course.highlights.slice(0, 3).map((item) => <li key={item}>{item}</li>)}
                        </ul>
                      </div>
                      <button type="button" className="mini-card__cover" onClick={() => setModal({ kind: "course", course })} aria-label={`Open ${course.title}`}>
                        <Cover variant={course.cover} />
                      </button>
                    </div>
                    <footer className="card-foot">
                      <span>{course.lessons}</span>
                      <button type="button" onClick={() => setModal({ kind: "course", course })}>Read it now →</button>
                    </footer>
                  </article>
                ))}
              </div>
            )}
          </div>
        </section>

        <section id="about-us" className="section section--ink educators">
          <div className="wrap">
            <header className="section__head">
              <h2>The <span>Educators</span></h2>
              <p>Who teaches, and what learners said after the exam. Tap a profile for the full bio.</p>
            </header>

            <div className="edu-grid">
              {educators.map((edu) => {
                const quotes = testimonials.filter((item) => item.educator === edu.name);
                return (
                  <div className="edu-block" key={edu.name}>
                    <article className="edu-card">
                      <span className="avatar avatar--lg">{edu.initials}</span>
                      <div className="edu-card__text">
                        <h3>{edu.name}</h3>
                        <p className="edu-card__role">{edu.role}</p>
                        <p className="edu-card__bio">{edu.bio}</p>
                        <ul className="cred-list">{edu.credentials.map((item) => <li key={item}>{item}</li>)}</ul>
                        <div className="socials">
                          {edu.socials.map((social) => (
                            <a key={social.label} href={social.href} target="_blank" rel="noreferrer" className={`soc soc--${social.kind}`}>
                              {social.label} <i>{social.handle}</i>
                            </a>
                          ))}
                        </div>
                      </div>
                    </article>

                    <div className="quote-list">
                      {quotes.map((quote, index) => (
                        <article className="quote-card" key={quote.name + index}>
                          <div className="quote-card__head">
                            <span className="avatar">{quote.initials}</span>
                            <div><b>{quote.name}</b><span>{quote.place}</span></div>
                            <span className="stars" aria-label={`${quote.rating} out of 5`}>{"★".repeat(quote.rating)}{"☆".repeat(5 - quote.rating)}</span>
                          </div>
                          <p>{quote.quote}</p>
                        </article>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        <section className="ticker" aria-hidden="true">
          <div className="ticker__row">
            {Array.from({ length: 2 }).map((_, block) => (
              <span key={block}>
                {["Geomorphology", "Climatology", "Oceanography", "Biogeography", "Population", "Economic Geography", "Indian Geography", "Geographical Thought", "GIS & Remote Sensing", "Quantitative Techniques"].map((item) => (
                  <em key={`${block}-${item}`}>{item}<i>◆</i></em>
                ))}
              </span>
            ))}
          </div>
        </section>

        <section id="contact" className="section section--soft contact">
          <div className="wrap contact__grid">
            <div className="contact__info">
              <header className="section__head section__head--left">
                <h2>Contact <span>Us</span></h2>
                <p>Course questions, a lecture that will not open, or an enrolment that did not arrive — write once, we reply on email.</p>
              </header>
              <div className="info-card">
                <h3>FREE (Geography)</h3>
                <p><b>Based in</b> Lucknow, Uttar Pradesh — 226005</p>
                <p><b>WhatsApp</b> <span>for course, technical or access issues</span><i>+91 70000 00000</i></p>
                <p><b>Email</b> <span>for grievances, certification and partnerships</span><i>hello@freegeography.in</i></p>
                <p><b>Hours</b> <span>Mon–Sat, 10:00–19:00 IST · replies within one working day</span></p>
                <button className="btn btn--primary" type="button" onClick={() => { goTo("full-courses"); flash("Pick a course, then tap Enrol free."); }}>Browse courses first</button>
              </div>
              <ul className="faq-mini">
                <li><b>Is anything hidden behind a paywall?</b><span>No. Lectures, notes and PYQs are free. Only printed booklets, verified certificates and priority doubt replies carry a fee.</span></li>
                <li><b>Do I need the app?</b><span>No — everything runs in the browser. The app is a convenience, not a requirement.</span></li>
                <li><b>Will validity expire?</b><span>Free courses do not expire. Add-ons with a 30-day window are stated on their offer card.</span></li>
              </ul>
            </div>

            <form className="form-card" onSubmit={submitEnquiry}>
              <header>
                <span className="eyebrow">WRITE TO THE TEAM</span>
                <h3>Tell us what you need</h3>
              </header>
              <div className="form-grid">
                <label>
                  <span>Your name <i>*</i></span>
                  <input required minLength={2} maxLength={120} value={contact.name} onChange={(e) => setContact({ ...contact, name: e.target.value })} placeholder="e.g. Priya Nair" autoComplete="name" />
                </label>
                <label>
                  <span>Email <i>*</i></span>
                  <input required type="email" maxLength={254} value={contact.email} onChange={(e) => setContact({ ...contact, email: e.target.value })} placeholder="you@example.com" autoComplete="email" />
                </label>
                <label>
                  <span>WhatsApp <small>optional</small></span>
                  <input type="tel" maxLength={30} value={contact.whatsapp} onChange={(e) => setContact({ ...contact, whatsapp: e.target.value })} placeholder="+91 …" autoComplete="tel" />
                </label>
                <label>
                  <span>Topic <i>*</i></span>
                  <select required value={contact.topic} onChange={(e) => setContact({ ...contact, topic: e.target.value })}>
                    <option value="">Choose one</option>
                    <option>Course content enquiry</option>
                    <option>Access or technical issue</option>
                    <option>Certificate / printed booklet</option>
                    <option>Teaching or partnership</option>
                    <option>Something else</option>
                  </select>
                </label>
              </div>
              <label className="form-full">
                <span>Message <i>*</i></span>
                <textarea required minLength={10} maxLength={2000} rows={5} value={contact.message} onChange={(e) => setContact({ ...contact, message: e.target.value })} placeholder="Which course, which lecture, and what happened…" />
              </label>
              <div className="hp" aria-hidden="true">
                <label>Leave this field empty<input tabIndex={-1} autoComplete="off" value={contact.website} onChange={(e) => setContact({ ...contact, website: e.target.value })} /></label>
              </div>
              {contactNote && <p className={`form-note ${contactState === "error" ? "form-note--bad" : "form-note--good"}`}>{contactNote}</p>}
              <button className="btn btn--primary btn--wide" type="submit" disabled={contactState === "sending"}>
                {contactState === "sending" ? "Sending…" : "Send message"}
              </button>
              <p className="form-legal">Your details are stored only to answer this enquiry. See the <a href="/policies/privacy">Privacy Policy</a>.</p>
            </form>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="wrap footer__grid">
          <div>
            <button className="brand brand--footer" type="button" onClick={() => goTo("hero")}>
              <CoverMark />
              <span className="brand__text"><span className="brand__name">FREE<i>.</i></span><span className="brand__sub">GEOGRAPHY</span></span>
            </button>
            <p className="punchline">To-the-point Courses &amp; Section-wise PYQs — without a fee.</p>
            <p className="footer__tiny">Made for learners who would rather revise than shop for resources.</p>
          </div>
          <nav aria-label="Footer — courses">
            <b>Learn</b>
            <button type="button" onClick={() => goTo("full-courses")}>Full courses</button>
            <button type="button" onClick={() => goTo("mini-courses")}>Mini courses</button>
            <button type="button" onClick={() => goTo("pyqs")}>Section-wise PYQs</button>
            <button type="button" onClick={() => goTo("free-courses")}>Free content</button>
          </nav>
          <nav aria-label="Footer — platform">
            <b>Platform</b>
            <button type="button" onClick={() => goTo("about-us")}>The educators</button>
            <button type="button" onClick={() => setModal({ kind: "help" })}>How it works</button>
            <button type="button" onClick={() => { setShowEnrolments(true); setNavOpen(false); }}>My courses</button>
            <button type="button" onClick={() => goTo("contact")}>Contact</button>
          </nav>
          <nav aria-label="Footer — policies">
            <b>Policies</b>
            <a href="/policies/privacy">Privacy Policy</a>
            <a href="/policies/terms">Terms &amp; Conditions</a>
            <a href="/policies/refund">Refund Policy</a>
            <a href="/policies/shipping">Shipping Policy</a>
          </nav>
        </div>
        <div className="wrap footer__bar">
          <span>© {new Date().getFullYear()} FREE (Geography). Learning stays free.</span>
          <span>Content is for exam preparation; always confirm the official notification.</span>
        </div>
      </footer>

      <div className="floaters">
        <button type="button" className="float float--help" onClick={() => setModal({ kind: "help" })} aria-label="How FREE Geography works">?</button>
        <button type="button" className={`float float--top${showTop ? " is-on" : ""}`} onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Back to top">↑</button>
      </div>

      {toast && (
        <div className="toast" role="status">
          <span>{toast}</span>
          <button type="button" onClick={() => setToast("")} aria-label="Dismiss">✕</button>
        </div>
      )}

      {modal && (
        <div className="overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) setModal(null); }}>
          <div className="sheet" role="dialog" aria-modal="true" aria-label={modal.kind === "course" ? modal.course.title : "Details"}>
            <button className="sheet__x" type="button" onClick={() => setModal(null)} aria-label="Close">✕</button>

            {modal.kind === "course" && (
              <>
                <div className="sheet__cover"><Cover variant={modal.course.cover} label={`${modal.course.type.toUpperCase()} · ${modal.course.exam.toUpperCase()}`} /></div>
                <div className="sheet__body">
                  <span className="eyebrow">{modal.course.subject}</span>
                  <h3>{modal.course.title}</h3>
                  <p className="sheet__lead">{modal.course.blurb}</p>
                  <dl className="sheet__facts">
                    <div><dt>Fee</dt><dd>₹0 · no expiry</dd></div>
                    <div><dt>Lessons</dt><dd>{modal.course.lessons}</dd></div>
                    <div><dt>Validity</dt><dd>{modal.course.validity}</dd></div>
                    <div><dt>Notes</dt><dd>{modal.course.notes ? "Included" : "Not included"}</dd></div>
                    <div><dt>Doubt support</dt><dd>{modal.course.doubt ? "Weekly live session" : "Email queue"}</dd></div>
                    <div><dt>Demo</dt><dd>{modal.course.demo ? "Free demo available" : "Full access free"}</dd></div>
                  </dl>
                  {modal.course.notice && <p className="note-line note-line--block">⚠ {modal.course.notice}</p>}
                  <div className="sheet__cols">
                    <div>
                      <b>You will cover</b>
                      <ol>{modal.course.syllabus.map((item) => <li key={item}>{item}</li>)}</ol>
                    </div>
                    <div>
                      <b>What's inside</b>
                      <ul className="dot-list">{modal.course.highlights.map((item) => <li key={item}>{item}</li>)}</ul>
                    </div>
                  </div>
                  <div className="sheet__cta">
                    {enrolledIds.includes(modal.course.id) ? (
                      <button className="btn btn--ok" type="button" onClick={() => { setShowEnrolments(true); setModal(null); }}>✓ Enrolled — open my courses</button>
                    ) : (
                      <button className="btn btn--primary" type="button" onClick={() => openEnrol(modal.course)}>Enrol free <span>→</span></button>
                    )}
                    <button className="btn btn--ghost" type="button" onClick={() => { setModal(null); goTo("contact"); }}>Ask a question</button>
                  </div>
                </div>
              </>
            )}

            {modal.kind === "promo" && (
              <div className="sheet__body sheet__body--pad">
                <span className="eyebrow">{modal.promo.subtitle}</span>
                <h3>{modal.promo.title}</h3>
                <p className="sheet__lead">{modal.promo.detail}</p>
                <div className="coupon">
                  <div>
                    <span>COUPON CODE</span>
                    <b>{modal.promo.code}</b>
                  </div>
                  <button type="button" onClick={() => copyCode(modal.promo.code)}>{copied === modal.promo.code ? "Copied ✓" : "Copy code"}</button>
                </div>
                <ul className="tick-list">{modal.promo.points.map((item) => <li key={item}><span>✓</span>{item}</li>)}</ul>
                <p className="sheet__fine">Applies to: {modal.promo.applies} · Discount {modal.promo.percent}% · {modal.promo.bonus}. Course content itself is free and needs no code.</p>
              </div>
            )}

            {modal.kind === "help" && (
              <div className="sheet__body sheet__body--pad">
                <span className="eyebrow">HOW IT WORKS</span>
                <h3>Four steps, no payment page</h3>
                <ol className="step-list">
                  <li><b>Pick your exam.</b> Use the filter chips to show only UGC-NET, UPSC, Class 11–12 or CTET resources.</li>
                  <li><b>Open a course.</b> Every card shows lecture count, what the course does <i>not</i> include, and the notes status.</li>
                  <li><b>Enrol free.</b> Name and email only — access is issued to that email, so check the spelling before confirming.</li>
                  <li><b>Revise with PYQs.</b> Finish a section, then attempt the matching question bank the same day.</li>
                </ol>
                <p className="sheet__fine">Content opens inside the app or website; bulk downloading is not available. Enrolment email cannot be changed after access is issued.</p>
              </div>
            )}

            {modal.kind === "enrolled" && (
              <div className="sheet__body sheet__body--pad success">
                <span className="tick-big">✓</span>
                <h3>You're enrolled</h3>
                <p className="sheet__lead"><b>{modal.title}</b> is now open on this device. Access details have been sent to your enrolment email — check spam once if it is not there within 10 minutes.</p>
                <p className="seat">Learner position in this cohort: <b>#{modal.seat}</b></p>
                <div className="sheet__cta">
                  <button className="btn btn--primary" type="button" onClick={() => { setModal(null); setShowEnrolments(true); }}>Open my courses</button>
                  <button className="btn btn--ghost" type="button" onClick={() => setModal(null)}>Back to site</button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {enrolTarget && (
        <div className="overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) setEnrolTarget(null); }}>
          <div className="sheet sheet--slim" role="dialog" aria-modal="true" aria-label="Free enrolment">
            <button className="sheet__x" type="button" onClick={() => setEnrolTarget(null)} aria-label="Close">✕</button>
            <div className="sheet__body sheet__body--pad">
              <span className="eyebrow">FREE ENROLMENT · ₹0</span>
              <h3>{enrolTarget.title}</h3>
              <p className="sheet__lead">{enrolTarget.lessons} · {enrolTarget.validity}. We only need enough details to issue your access.</p>
              <form className="enrol-form" onSubmit={submitEnrolment}>
                <label>
                  <span>Full name <i>*</i></span>
                  <input required minLength={2} maxLength={120} autoComplete="name" value={enrolForm.fullName} onChange={(e) => setEnrolForm({ ...enrolForm, fullName: e.target.value })} placeholder="As it should appear on your access" />
                </label>
                <label>
                  <span>Email <i>*</i></span>
                  <input required type="email" autoComplete="email" value={enrolForm.email} onChange={(e) => setEnrolForm({ ...enrolForm, email: e.target.value })} placeholder="Your own email — it cannot be changed later" />
                </label>
                <label>
                  <span>WhatsApp <small>optional</small></span>
                  <input type="tel" maxLength={30} value={enrolForm.whatsapp} onChange={(e) => setEnrolForm({ ...enrolForm, whatsapp: e.target.value })} placeholder="+91 …" />
                </label>
                <div className="hp" aria-hidden="true"><label><input tabIndex={-1} value={enrolForm.website} onChange={(e) => setEnrolForm({ ...enrolForm, website: e.target.value })} /></label></div>
                <p className="enrol-fine">By enrolling you accept the <a href="/policies/terms">Terms</a> and <a href="/policies/privacy">Privacy Policy</a>. Fee is non-refundable because there is none; add-on refunds follow the Refund Policy.</p>
                {enrolError && <p className="form-note form-note--bad">{enrolError}</p>}
                <button className="btn btn--primary btn--wide" type="submit" disabled={enrolState === "sending"}>{enrolState === "sending" ? "Issuing access…" : "Confirm free enrolment"}</button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  function openEnrol(course: Course) {
    setEnrolTarget(course);
    setEnrolError("");
    setEnrolState("idle");
  }
}

/* Local state kept outside the render body helpers */
function CoverMark() {
  return (
    <span className="mark" aria-hidden="true">
      <svg viewBox="0 0 44 44">
        <circle cx="22" cy="22" r="19" fill="none" stroke="currentColor" strokeWidth="1.6" />
        <circle cx="22" cy="22" r="14.5" fill="none" stroke="currentColor" strokeWidth=".8" strokeDasharray="1.6 2.6" />
        <path d="M22 6.5v31M6.5 22h31" stroke="currentColor" strokeWidth=".9" />
        <path d="m26 14-3.8 8.2L14 26l3.8-8.2L26 14Z" fill="currentColor" />
      </svg>
    </span>
  );
}

function EmptyNote({ onReset }: { onReset: () => void }) {
  return (
    <div className="empty">
      <b>Nothing matches this filter yet.</b>
      <p>This exam track has no card in that section. Clear the filter to see the rest of the library.</p>
      <button type="button" onClick={onReset}>Show all resources</button>
    </div>
  );
}
