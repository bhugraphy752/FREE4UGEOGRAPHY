import {
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

/** People who ask a question from the Contact section. */
export const freeInquiries = pgTable("free_inquiries", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 254 }).notNull(),
  whatsapp: varchar("whatsapp", { length: 30 }),
  topic: varchar("topic", { length: 120 }).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/** Free-course enrolments (the "Enrol free" action on every course card). */
export const freeEnrollments = pgTable("free_enrollments", {
  id: serial("id").primaryKey(),
  fullName: varchar("full_name", { length: 120 }).notNull(),
  email: varchar("email", { length: 254 }).notNull(),
  whatsapp: varchar("whatsapp", { length: 30 }),
  courseId: varchar("course_id", { length: 60 }).notNull(),
  courseTitle: varchar("course_title", { length: 200 }).notNull(),
  examTrack: varchar("exam_track", { length: 120 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
